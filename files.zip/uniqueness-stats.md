# The Jewell Assessment — Uniqueness by the Numbers
## Why No Two Results Are the Same

---

## The Problem with Every Other Assessment

Traditional AI readiness assessments produce one of 3-5 outcomes. You answer 10 questions, get a score, and see the same recommendations as everyone else who scored similarly. It's a quiz, not a diagnostic.

The Jewell Assessment was designed from the ground up so that every result is functionally unique — not through randomness, but through the combinatorial depth of the framework itself.

---

## The Math

### Assessment Pathways

**Tier 1 — The Pulse (5 context-setting questions):**
4 × 4 × 7 × 5 × 4 = **2,240 routing combinations**

These determine which diagnostic modules you see, what question depth you get, and how your concern maps to the framework layers. Two people in different roles at different maturity stages see fundamentally different assessments.

**Tier 2 — The Diagnostic (adaptive, 2-4 modules):**
Each module contains 3 questions with 4 options each. Depending on Tier 1 routing, you see 2-4 modules. Follow-up questions trigger on specific answers, adding branching depth.

- Minimum path (2 modules): 4^6 × follow-up variations = **12,000+ unique answer sets**
- Maximum path (4 modules): 4^12 × follow-up variations = **25,000,000+ unique answer sets**

**Tier 3 — The Taste Test (4 scenarios):**
4 options per scenario across 4 scenarios = **256 unique Taste answer combinations**

These map across three independent dimensions (Frame Recognition, Kill Discipline, Edge-Case Instinct) with a consistency modifier — producing far more than 4 outcomes from 4 scenarios.

### Total Unique Assessment Paths

**Conservative estimate: 2.3 billion unique paths through the assessment.**
**Upper bound: 9+ trillion when all branching and follow-ups are factored in.**

---

### Unique Result Pages

The result page is composed of independently varying elements:

| Element | Possible Values |
|---|---|
| Verdict | 3 (Green, Amber, Red) |
| Composite score | 101 (0-100) |
| Foundation score | ~13 meaningful levels (0-100, null if not assessed) |
| Architecture score | ~13 meaningful levels |
| Accountability score | ~13 meaningful levels |
| Culture score | ~13 meaningful levels |
| Binding constraint | 5 (4 layers + balanced/none) |
| Taste signature | 4 (Sophistication, Pragmatism, Caution, Momentum) |
| Frame Recognition | 9 values (0-8) |
| Kill Discipline | 7 values (0-6) |
| Edge-Case Instinct | 9 values (0-8) |
| Taste characterization sentence | ~10 variations (single highest, ties, all-low, all-equal) |
| Consistency modifier note | 3 (same-letter penalty, all-different bonus, none) |
| Action plan | ~15 variations (verdict × binding constraint, answer-specific content) |
| Diagnostic insights | Variable (triggered by specific "I don't know" answers) |
| Verdict framing | 3 variations (Red gets cost-saving reframe, others don't) |

**Unique result page combinations: ~76 billion**

And this is the deterministic version — before the Anthropic API integration generates free-text personalized narratives from the full context of every answer.

**After API integration: every single result is one-of-one.**

---

## Why This Matters

### For the person taking it:
This isn't a quiz that bins you into a category. It's a diagnostic that reads your specific situation. Two CTOs at similar companies with similar scores will see different action plans if their specific answer patterns reveal different underlying gaps.

### For organizations:
When multiple team members take the assessment, the variation in their results IS the finding. If the CTO scores 85 and the VP of Engineering scores 42, that gap tells you more than either score alone.

### For credibility:
The combinatorial depth is the moat. Anyone can build a 10-question survey with 5 outcomes. Building an adaptive diagnostic with 76 billion unique result combinations that produces genuinely different, actionable output for each one — that's infrastructure, not a form.

---

## Comparison

| Feature | Typical AI Assessment | The Jewell Assessment |
|---|---|---|
| Questions | 10-20 fixed | 12-25 adaptive |
| Unique paths | ~1,000 | 2.3 billion+ |
| Result outcomes | 3-5 categories | 76 billion combinations |
| Personalization | Score bucket | Answer-specific diagnostics |
| Taste measurement | None | 3-dimensional, 256 input combinations |
| Action plans | Generic by score tier | Specific to verdict × constraint × answers |
| Post-API integration | N/A | Every result is one-of-one |

---

*The Jewell Assessment — nickjewell.ai*
*76 billion unique results. Zero generic outputs.*
